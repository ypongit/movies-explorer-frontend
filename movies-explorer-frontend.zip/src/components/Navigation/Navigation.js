import React from "react";
import { Link, Route } from 'react-router-dom';

function Navigation(){
  return (
    <div className="navigation">
      <nav>
        <ul className="navigation__links">
          <Link>

          </Link>
        </ul>
      </nav>
    </div>
  )
}

export default Navigation;