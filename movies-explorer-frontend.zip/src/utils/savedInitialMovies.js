import img1 from "../images/cardimg/33words.png";
import img2 from "../images/cardimg/kinoalmanach.png";
import img3 from "../images/cardimg/benksi.png";


const savedInitialMovies = [
  {
    name: '33 слова о дизайне',
    link: img1
  },
  {
    name: 'Киноальманах «100 лет дизайна»',
    link: img2
  },
  {
    name: 'В погоне за Бенкси',
    link: img3
  }
];

export default savedInitialMovies;