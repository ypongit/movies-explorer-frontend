# movies-explorer-frontend

[Ссылка на пул-реквест](https://github.com/ypongit/movies-explorer-frontend/pull/2)  
[Ссылка на сайт, размещенный на Яндекс.Облаке](http://movies-explorer.ypon.nomoredomains.xyz/)  
Домен для фронтенда: [movies-explorer.ypon.nomoredomains.xyz]  
Домен для бэкенда: [api.movies-explorer.ypon.nomoredomains.xyz]
Публичный IP-адрес сервера: **130.193.55.132** 
